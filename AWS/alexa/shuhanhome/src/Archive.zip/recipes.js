module.exports = {
    "RECIPE_EN_GB" : {
        "glow stone dust": "Glow stone dust is obtained by breaking glow stone blocks.",
    },
    "RECIPE_EN_US" : {
	"shuhan": "A girl, 3 years old.",
	"father": "Mingjun GENG",
    },
    "RECIPE_DE_DE" : {
        "schneegolem": "Ein Schneegolem kann erschaffen werden, indem ein Kürbis auf zwei auf dem Boden stehende Schneeblöcke gesetzt wird.",
    }
};
